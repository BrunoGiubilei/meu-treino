/* =========================================================
   Meu Treino — Ponto de entrada: liga as peças e desenha a primeira tela.
   ========================================================= */

import { markChanged, setRenderer, syncNow } from './cloud.js';
import { startElapsed } from './elapsed.js';
import { bindEvents } from './events.js';
import { refreshRest, restoreRest, setRestDoneHandler } from './rest.js';
import { startRouter } from './router.js';
import { mountShell } from './shell.js';
import { onStateChanged, saveState } from './state.js';
import { initTheme } from './theme.js';
import { loadVersions } from './version.js';
import { bindOverlay } from './views/overlays.js';
import { render } from './views/render.js';

onStateChanged(markChanged);   // dado mudou -> a sincronização é avisada
setRenderer(render);           // a sincronização sabe redesenhar a tela
bindEvents();
bindOverlay();
startElapsed();

initTheme();
mountShell();
startRouter(render);   // lê o endereço de abertura (#/...) e acompanha voltar/avançar

render();
loadVersions();       // mostra a versão do sw.js na página Aparência
setRestDoneHandler(() => {   // o descanso contou uma série: grava e redesenha
  saveState();
  render();
});
restoreRest();        // retoma o descanso se o app foi fechado/descartado no meio dele
syncNow();

window.addEventListener('online', syncNow);
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    refreshRest();
    syncNow();
  }
});

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js');
  });
}
